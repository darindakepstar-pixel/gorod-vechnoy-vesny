-- Миграция для игры «Город вечной весны». Запускать в SQL Editor Supabase.
-- Идемпотентно: можно выполнять повторно.

create table if not exists players (
  id         uuid primary key,
  nickname   text not null,
  created_at timestamptz default now()
);

create table if not exists saves (
  player_id  uuid not null references players(id) on delete cascade,
  slot       text not null,
  state      jsonb not null,
  updated_at timestamptz default now(),
  primary key (player_id, slot)
);

create table if not exists endings (
  player_id  uuid not null references players(id) on delete cascade,
  ending_id  text not null,
  reached_at timestamptz default now(),
  primary key (player_id, ending_id)
);

alter table players enable row level security;
alter table saves   enable row level security;
alter table endings enable row level security;

-- Игра для узкого круга: разрешаем анонимный доступ.
-- Если однажды ссылка уйдёт наружу, поменяй на полноценную авторизацию.
do $$
begin
  if not exists (select 1 from pg_policies where tablename='players' and policyname='open_players') then
    create policy open_players on players for all using (true) with check (true);
  end if;
  if not exists (select 1 from pg_policies where tablename='saves' and policyname='open_saves') then
    create policy open_saves on saves for all using (true) with check (true);
  end if;
  if not exists (select 1 from pg_policies where tablename='endings' and policyname='open_endings') then
    create policy open_endings on endings for all using (true) with check (true);
  end if;
end $$;

-- Общая статистика: кто до чего дошёл.
create or replace view stats as
select p.nickname,
       count(distinct e.ending_id) as endings_found,
       max(e.reached_at)           as last_ending,
       (s.state->'love'->>'lei')::int  as lei,
       (s.state->'love'->>'tank')::int as tank,
       (s.state->'love'->>'shen')::int as shen,
       s.state->>'scene'               as current_scene
from players p
left join endings e on e.player_id = p.id
left join saves   s on s.player_id = p.id and s.slot = 'auto'
group by p.nickname, s.state;
